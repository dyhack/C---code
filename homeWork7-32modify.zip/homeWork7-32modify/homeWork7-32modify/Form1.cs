﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace homeWork7_32modify
{
    public partial class Form1 : Form
    {
        DataSet ds;
        SqlDataAdapter adapter;
        string dataMember;
        int recordCount;
        public Form1()
        {
            InitializeComponent();
            dataMember = "employee";
            BuildData();
            BindData();
            recordCount = this.BindingContext[ds, dataMember].Count;
            ShowPosition();
        }
        private void ShowPosition() 
        {
            if(recordCount==0)
            {
                this.btnCurrent.Text = "无记录";
                textBox1.Text = textBox2.Text = textBox3.Text = textBox4.Text = "";
            }
            else
            {
                int position = this.BindingContext[ds, dataMember].Position + 1;
                this.btnCurrent.Text = string.Format("{0}of{1}", position, recordCount);
                this.trackBar1.Value = position - 1;
            }
        }
        private void BuildData()
        {
            string connString = "server=localhost;Integrated Security=SSPI;database=pubs";
            string sqlstr = "select * from employee";
            SqlConnection conn = new SqlConnection(connString);
            adapter = new SqlDataAdapter(sqlstr, conn);
            SqlCommandBuilder builder = new SqlCommandBuilder(adapter);
            //------------------------------------------------------------------
            adapter.InsertCommand = builder.GetInsertCommand();
            adapter.DeleteCommand = builder.GetDeleteCommand();
            adapter.UpdateCommand = builder.GetUpdateCommand();

            //------------------------------------------------------------------
            ds = new DataSet();
            adapter.Fill(ds, dataMember);
        }
        private void BindData()
        {
            this.dataGrid1.AllowSorting = false;
            this.dataGrid1.SetDataBinding(ds, dataMember);
            this.textBox1.DataBindings.Add(new Binding("Text", ds, "employee.emp_id"));
            this.textBox2.DataBindings.Add(new Binding("Text", ds, "employee.fname"));
            this.textBox3.DataBindings.Add(new Binding("Text", ds, "employee.lname"));
            this.textBox4.DataBindings.Add(new Binding("Text", ds, "employee.hire_date"));
            this.trackBar1.Minimum = 0;
            this.trackBar1.Maximum = this.BindingContext[ds, dataMember].Count - 1;
        }

        private void btnFirst_Click(object sender, EventArgs e)
        {
            this.BindingContext[ds, dataMember].Position = 0;
            ShowPosition();
        }

        private void btnPre_Click(object sender, EventArgs e)
        {
            if(this.BindingContext[ds,dataMember].Position>0)
            {
                this.BindingContext[ds, dataMember].Position -= 1;
                ShowPosition();
            }
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            this.BindingContext[ds, dataMember].Position += 1;
            ShowPosition();
        }

        private void btnLast_Click(object sender, EventArgs e)
        {
            this.BindingContext[ds, dataMember].Position = recordCount - 1;
            ShowPosition();
        }

        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            this.BindingContext[ds, dataMember].Position = this.trackBar1.Value;
            ShowPosition();
        }

        private void dataGrid1_Click(object sender, EventArgs e)
        {
            this.BindingContext[ds, dataMember].Position = this.dataGrid1.CurrentRowIndex;
            ShowPosition();
        }

        private void dataGrid1_CurrentCellChanged(object sender, EventArgs e)
        {
            if(recordCount<=this.dataGrid1.CurrentCell.RowNumber)
            {
                recordCount = this.dataGrid1.CurrentCell.RowNumber + 1;
                this.trackBar1.Maximum = recordCount - 1;
            }
            this.BindingContext[ds, dataMember].Position = this.dataGrid1.CurrentCell.RowNumber;
            ShowPosition();
        }
//----------------------------------------------------------------------------------
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if(ds.HasChanges())
            {
                DialogResult result = MessageBox.Show("数据尚未保存，保存所做的修改吗？", 
                    "提示", MessageBoxButtons.YesNoCancel);
                switch(result)
                {
                    case DialogResult.Yes:
                        try
                        {
                            this.adapter.Update(ds, "employee");
                            e.Cancel = false;
                        }
                        catch(Exception err)
                        {
                            MessageBox.Show(err.Message, "错误",
                               MessageBoxButtons.OK ,MessageBoxIcon.Error);
                            e.Cancel = true;
                        }
                        break;
                    case DialogResult.No:
                        e.Cancel = false;
                        break;
                    case DialogResult.Cancel:
                        e.Cancel = true;
                        break;
                }
            }
        }
    }
}
